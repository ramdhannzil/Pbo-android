import 'package:flutter/material.dart';

class DetailPage extends StatelessWidget {
  const DetailPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: Column(
        children: [
          //Image
          Image.asset("FarmLembang.jpg"),

          // Title
          Container(
            padding: const EdgeInsets.all(10),
            child: Text("Farm House Lembang", style: TextStyle(fontSize: 30),
            textAlign: TextAlign.center),
          ),

          //Informasi
          Container(
            padding: const EdgeInsets.symmetric(vertical: 20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                //Column Pertam
                Column(
                  children: [
                    Icon(Icons.date_range),
                    Text("Open Everyday")
                  ],
                ),
                //Column Ketiga 
                Column(
                  children: [
                    Icon(Icons.watch),
                    Text("09:00 - 20:00")
                  ],
                ),
                //Column Ketiga
                Column(
                  children: [
                    Icon(Icons.monetization_on),
                    Text("Rp. 25.000")
                  ],
                )
              ],
            ),
          ),

          //Deskripsi
          Container(
            padding: const EdgeInsets.symmetric(),
            child: Text("Farm Lembang adalah sebuah ladang pertanian yang terletak di Lembang, Banyak wisatawan yang datang ke tempat tersebut hanya sekedar untuk mencicipi hasil bumi yang ada di Lembang", textAlign: TextAlign.center,
            ),
          )
        ],
      )),
    );
  }
}